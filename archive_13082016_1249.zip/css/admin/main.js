




/*
     FILE ARCHIVED ON 12:30:30 фев 22, 2016 AND RETRIEVED FROM THE
     INTERNET ARCHIVE ON 14:23:37 фев 25, 2016.
     JAVASCRIPT APPENDED BY WAYBACK MACHINE, COPYRIGHT INTERNET ARCHIVE.

     ALL OTHER CONTENT MAY ALSO BE PROTECTED BY COPYRIGHT (17 U.S.C.
     SECTION 108(a)(3)).
*/
/**
 * main.js
 * /web/20160222123030/http://www.codrops.com
 *
 * Licensed under the MIT license.
 * /web/20160222123030/http://www.opensource.org/licenses/mit-license.php
 * 
 * Copyright 2014, Codrops
 * /web/20160222123030/http://www.codrops.com
 */
(function() {

	var bodyEl = document.body,
		overlay = document.querySelector( '.overlay' ),
		openbtn = document.getElementById( 'profile-menu-link' ),
		closebtn = document.getElementById( 'close-button' ),
		isOpen = false;

	function init() {
		initEvents();
	}

	function initEvents() {
		openbtn.addEventListener( 'click', toggleMenu );
		if( closebtn ) {
			closebtn.addEventListener( 'click', toggleMenu );
		}

		// close the menu element if the target it´s not the menu element or one of its descendants..
		overlay.addEventListener( 'click', function(ev) {
			var target = ev.target;
			if( isOpen && target !== openbtn ) {
				toggleMenu();
			}
		} );
	}

	function toggleMenu() {
		if( isOpen ) {
			classie.remove( bodyEl, 'show-menu' );
		}
		else {
			classie.add( bodyEl, 'show-menu' );
		}
		isOpen = !isOpen;
	}

	init();

})();